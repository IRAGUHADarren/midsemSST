
package DbConnect;

import java.sql.*;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Db_Connect {
    public static void main(String[] args) {
        String dbUrl="jdbc:mysql://localhost/auca";
        String username="root";
        String password="";
        
        try {
            Connection con= DriverManager.getConnection(dbUrl, username, password);
            Statement st= con.createStatement();
            String sql="create table Student(student_id int primary key, first_name varchar(50),last_name varchar(50),date_of_birth varchar(50))";
            String now="create table Semester(semester_id int primary key, semester_name varchar(50), starting_date varchar(50),end_date varchar(50) )";
            String maid="create table StudentRegistration(registration_id int primary key, registration_code varchar(50), registration_date timestamp,student_id int,semester_id varchar(50),department_id int  )";
            String teacher="create table teacher(teacher_id int primary key, first_name varchar(50), last_name varchar(50),qualification varchar(50), course_id int)";
            String course="create table course(course_id int primary key, course_code varchar(50),course_name varchar(50), semester_id int,department_id int)";
            String then="create table course_definition(course_def_id int primary key, course_def_code varchar(50), course_def_descr varchar(50), course_id int)";
            String table="create table acadenic_unit(academic_id int primary key, academic_code varchar(50), academic_name varchar(50),type varchar(50),parent_id int )";
            int row=st.executeUpdate(sql);
            int column=st.executeUpdate(now);
            int dom=st.executeUpdate(maid);
            int clear=st.executeUpdate(teacher);
            int surf=st.executeUpdate(course);
            int clone=st.executeUpdate(then);
            int hoe=st.executeUpdate(table);
            con.close();
            if(row>0){
                System.out.println("student not created");
            }else if(column>0){
                System.out.println("semester not created");
            } else if(dom>0){
                System.out.println("Registration not created");
            }else if(clear>0){
                System.out.println("techer not created");
            }else if(surf>0){
                System.out.println("course not created");
            }else if(clone>0){
                System.out.println("definition not created");
            }else if(hoe>0){
                System.out.println(" unit not created");
            }else{
                System.out.println("all tables created");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
