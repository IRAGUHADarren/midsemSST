
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Student;

/**
 *
 * @author IRAGUHA DARREN
 */
public class StudentDao {
    private String dburl="jdbc:mysql://localhost:3306/auca";
    private String username="root";
    private String passwd="";
    String sql;
    int rowsAffected;

    public StudentDao() {
    }
    public String registerStudent(Student studentObj){
        try {
                Connection con= DriverManager.getConnection(dburl, username, passwd);
                sql="insert into student values(?,?,?,?) ";
                PreparedStatement pst=con.prepareStatement(sql);
                pst.setInt(1, studentObj.getStudid());
                pst.setString(2,studentObj.getFname() );
                pst.setString(3,studentObj.getLname() );
                pst.setString(4,studentObj.getDob() );

                rowsAffected= pst.executeUpdate();
                con.close();
                if(rowsAffected>0){
                    System.out.println("data saved ");
                }else{
                    System.out.println("data not saved");
                }
            } catch (Exception e) {
            e.printStackTrace();
        }
        return "server error";
    }
    public List<Student>allStudent(){
        try {
            Connection con= DriverManager.getConnection(dburl, username, passwd);
            sql="select * from student";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet result=pst.executeQuery();
            List<Student> studentList= new ArrayList<>();
            while(result.next()){
                Student studentObj=new Student();
                studentObj.setStudid(result.getInt("ID"));
                studentObj.setFname(result.getString("First_NAMES"));
                studentObj.setLname(result.getString("last_name"));
                studentObj.setDob(result.getString("date_of_birth"));
;
                studentList.add(studentObj);
            }
            con.close();
            return studentList;

            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
}
