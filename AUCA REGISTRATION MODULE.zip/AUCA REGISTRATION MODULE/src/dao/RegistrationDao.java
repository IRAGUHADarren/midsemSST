
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Registration;

/**
 *
 * @author IRAGUHA DARREN
 */
public class RegistrationDao {
    private String dburl="jdbc:mysql://localhost:3306/auca";
    private String username="root";
    private String passwd="";
    String sql;
    int rowsAffected;

    public RegistrationDao() {
    }
    public String registerRegistration(Registration studentObj){
        try {
                Connection con= DriverManager.getConnection(dburl, username, passwd);
                sql="insert into studentregistration values(?,?,?,?,?,?) ";
                PreparedStatement pst=con.prepareStatement(sql);
                pst.setInt(1, studentObj.getReg_id());
                pst.setString(2,studentObj.getCode() );
                pst.setString(3,studentObj.getDate() );
                pst.setInt(4,studentObj.getStud_id() );
                pst.setInt(5, studentObj.getSeme_id());
                pst.setInt(6, studentObj.getDepart_id());

                rowsAffected= pst.executeUpdate();
                con.close();
                if(rowsAffected>0){
                    System.out.println("data saved ");
                }else{
                    System.out.println("data not saved");
                }
            } catch (Exception e) {
            e.printStackTrace();
        }
        return "server error";
    }
    public Registration allRegistration(Registration studentObj){
        try {
            Connection con= DriverManager.getConnection(dburl, username, passwd);
            sql="select * from studentregistration where semester_id =? and department_id=?";
            PreparedStatement pst=con.prepareStatement(sql);
            pst.setInt(1, studentObj.getSeme_id());
            pst.setInt(2, studentObj.getDepart_id());
            ResultSet result=pst.executeQuery();
            Registration thereg= new Registration(); 
            if(result.next()){
                
                studentObj.setReg_id(result.getInt("ID"));
                studentObj.setCode(result.getString("registration_code"));
                studentObj.setDate(result.getString("registration_date"));
                studentObj.setSeme_id(result.getInt("semester_id"));
                studentObj.setStud_id(result.getInt("student_id"));
                studentObj.setDepart_id(result.getInt("department_id"));
                con.close();
                return thereg;

               
            }
            

            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
}
