/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Teacher {
    private int teach_id;
    private int cours_id;
    private String fname;
    private String lname;
    private String qualification;

    public Teacher() {
    }

    public Teacher(int teach_id, int cours_id, String fname, String lname, String qualification) {
        this.teach_id = teach_id;
        this.cours_id = cours_id;
        this.fname = fname;
        this.lname = lname;
        this.qualification = qualification;
    }

    public int getTeach_id() {
        return teach_id;
    }

    public void setTeach_id(int teach_id) {
        this.teach_id = teach_id;
    }

    public int getCours_id() {
        return cours_id;
    }

    public void setCours_id(int cours_id) {
        this.cours_id = cours_id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    
}
