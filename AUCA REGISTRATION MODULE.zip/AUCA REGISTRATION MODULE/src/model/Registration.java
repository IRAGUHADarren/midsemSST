
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Registration {
    private int reg_id;
    private int stud_id;
    private int depart_id;
    private int seme_id;
    private String code;
    private String date;

    public Registration() {
    }

    public Registration(int reg_id, int stud_id, int depart_id, int seme_id, String code, String date) {
        this.reg_id = reg_id;
        this.stud_id = stud_id;
        this.depart_id = depart_id;
        this.seme_id = seme_id;
        this.code = code;
        this.date = date;
    }

    public int getReg_id() {
        return reg_id;
    }

    public void setReg_id(int reg_id) {
        this.reg_id = reg_id;
    }

    public int getStud_id() {
        return stud_id;
    }

    public void setStud_id(int stud_id) {
        this.stud_id = stud_id;
    }

    public int getDepart_id() {
        return depart_id;
    }

    public void setDepart_id(int depart_id) {
        this.depart_id = depart_id;
    }

    public int getSeme_id() {
        return seme_id;
    }

    public void setSeme_id(int seme_id) {
        this.seme_id = seme_id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
}
