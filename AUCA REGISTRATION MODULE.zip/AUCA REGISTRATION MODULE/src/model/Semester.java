
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Semester {
    private int semid;
    private String semName;
    private String startdate;
    private String enddate;

    public Semester() {
    }

    public int getSemid() {
        return semid;
    }

    public void setSemid(int semid) {
        this.semid = semid;
    }

    public String getSemName() {
        return semName;
    }

    public void setSemName(String semName) {
        this.semName = semName;
    }

    public String getStartdate() {
        return startdate;
    }

    public void setStartdate(String startdate) {
        this.startdate = startdate;
    }

    public String getEnddate() {
        return enddate;
    }

    public void setEnddate(String enddate) {
        this.enddate = enddate;
    }

    public Semester(int semid, String semName, String startdate, String enddate) {
        this.semid = semid;
        this.semName = semName;
        this.startdate = startdate;
        this.enddate = enddate;
    }
    
}
