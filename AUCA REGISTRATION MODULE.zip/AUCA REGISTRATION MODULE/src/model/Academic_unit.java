
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Academic_unit {
    private int acade_id;
    private String acade_code;
    private int parent_id;
    private String name;
    private String type;

    public Academic_unit() {
    }

    public Academic_unit(int acade_id, String acade_code, int parent_id, String name, String type) {
        this.acade_id = acade_id;
        this.acade_code = acade_code;
        this.parent_id = parent_id;
        this.name = name;
        this.type = type;
    }

    public int getAcade_id() {
        return acade_id;
    }

    public void setAcade_id(int acade_id) {
        this.acade_id = acade_id;
    }

    public String getAcade_code() {
        return acade_code;
    }

    public void setAcade_code(String acade_code) {
        this.acade_code = acade_code;
    }

    public int getParent_id() {
        return parent_id;
    }

    public void setParent_id(int parent_id) {
        this.parent_id = parent_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
