
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Student {
    private int studid;
    private String fname;
    private String lname;
    private String dob;

    public Student() {
    }

    public int getStudid() {
        return studid;
    }

    public void setStudid(int studid) {
        this.studid = studid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public Student(int studid, String fname, String lname, String dob) {
        this.studid = studid;
        this.fname = fname;
        this.lname = lname;
        this.dob = dob;
    }
    
}
