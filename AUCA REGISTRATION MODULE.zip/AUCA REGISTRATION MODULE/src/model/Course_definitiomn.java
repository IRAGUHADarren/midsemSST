/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Course_definitiomn {
    private int id;
    private String code;
    private int course_id;
    private String description;

    public Course_definitiomn() {
    }

    public Course_definitiomn(int id, String code, int course_id, String description) {
        this.id = id;
        this.code = code;
        this.course_id = course_id;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
