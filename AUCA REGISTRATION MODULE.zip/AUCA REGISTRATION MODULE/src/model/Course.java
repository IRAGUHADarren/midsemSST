
package model;

/**
 *
 * @author IRAGUHA DARREN
 */
public class Course {
    private int cours_id;
    private String cours_code;
    private String cours_name;
    private int sem_id;
    private int depar_id;

    public Course() {
    }

    public Course(int cours_id, String cours_code, String cours_name, int sem_id, int depar_id) {
        this.cours_id = cours_id;
        this.cours_code = cours_code;
        this.cours_name = cours_name;
        this.sem_id = sem_id;
        this.depar_id = depar_id;
    }

    public int getCours_id() {
        return cours_id;
    }

    public void setCours_id(int cours_id) {
        this.cours_id = cours_id;
    }

    public String getCours_code() {
        return cours_code;
    }

    public void setCours_code(String cours_code) {
        this.cours_code = cours_code;
    }

    public String getCours_name() {
        return cours_name;
    }

    public void setCours_name(String cours_name) {
        this.cours_name = cours_name;
    }

    public int getSem_id() {
        return sem_id;
    }

    public void setSem_id(int sem_id) {
        this.sem_id = sem_id;
    }

    public int getDepar_id() {
        return depar_id;
    }

    public void setDepar_id(int depar_id) {
        this.depar_id = depar_id;
    }
    
}
